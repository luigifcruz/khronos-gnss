#include "aulora.pb-c.h"
#include <stdio.h>

int main()
{
    Main__Shuttle *msg;

    FILE *fp;
    char buf[30];

    fp = fopen("./shuttle.pb", "rb");
    fread(buf, sizeof(buf), 1, fp);

    msg = main__shuttle__unpack(NULL, sizeof(buf), buf);
    if (msg == NULL)
    {
        fprintf(stderr, "error unpacking incoming message\n");
        return 0;
    }

    printf("Sender: %s\n", msg->sender);
    printf("Receiver: %s\n", msg->receiver);

    for (int i = 0; i < sizeof(buf); i++)
    {
        printf("0x%02X, ", (unsigned char)buf[i]);
    }

    return 0;
}